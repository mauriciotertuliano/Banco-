/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/SQLTemplate.sql to edit this template
 */
/**
 * Author:  marcos
 * Created: 16 de mai de 2023
 */
CREATE TABLE public.contato (
	nome varchar NULL,
	email varchar NULL,
	telefone varchar NULL
);